#pragma once
#ifndef FP16_H
#define FP16_H

#include <fp16/fp16.h>

#if defined(PSIMD_H)
#include <fp16/psimd.h>
#endif

#endif /* FP16_H */
